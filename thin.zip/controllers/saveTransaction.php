<?php

if(isset($_GET['job_id'])){
	$job=$_GET['job_id'];

	echo 'job id id '.$job;
	
}

?>